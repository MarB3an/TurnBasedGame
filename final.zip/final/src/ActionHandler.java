import java.util.Random;

public class ActionHandler{
    // for PvP
    public static boolean playerAction(Character player, Character opponent, int action){
        return executeAction(player, opponent, action);
    }
     // for PvE
    public static boolean playerAction(Character player, Enemy enemy, int action, Random random){ 
        return executeAction(player, enemy, action);
    }
    //mao ni method handle actions for both PvP and PvE
    private static boolean executeAction(Character player, Object target, int action){
        switch(action){
            case 1: { // Basic Attack
                int damage = player.attack();
                applyDamage(target, damage);
                System.out.println("\n\t\t\t\t\t\t" + player.getName() + " dealt " + damage + " damage to " + getName(target) + "!\n");
                player.giveMana(10);
                return false;
            }
            case 2: { // Defend
                if(player.getMana() >= 25){
                    System.out.println("\t\t\t\t\t\t "+player.getName() + " is defending! Incoming damage will be reduced.");
                    player.defend();
                    player.takeMana(25);
                    return false;
                }else{
                    System.out.println("\t\t\t\t\t\tNot enough mana to defend.");
                    return true;
                }
            }
            case 3: { // Special Attack
                if(player.getMana() >= 50){
                    int specialDamage = player.specialAttack();
                    applyDamage(target, specialDamage);
                    System.out.println("\t\t\t\t\t\t "+player.getName() + " used a special attack and dealt " + specialDamage + " damage to " + getName(target) + "!");
                    player.takeMana(50);
                    return false;
                }else{
                    System.out.println("\t\t\t\t\t\tNot enough mana for a special attack.");
                    return true;
                }
            }
            default: {
                System.out.println("\t\t\t\t\t\tInvalid action. Try again!");
                return true;
            }
        }
    }
    //mao ni helper method para ma apply and damage either sa character or enemy.
    private static void applyDamage(Object target, int damage){
        if(target instanceof Character character){
            character.takeDamage(damage);
        }else if(target instanceof Enemy enemy){
            enemy.takeDamage(damage);
        }
    }
    //function ni niya ky helper method ra gyapon para ma kuha ang name sa character or enemy
    private static String getName(Object target){
        if(target instanceof Character character){
            return character.getName();
        }else if(target instanceof Enemy enemy){
            return enemy.getName();
        }
        return "Unknown";
    }

} 