import java.util.Random;
import java.util.Scanner;


public class Main {

    private static String reset = "\033[0m";
    private static String red = "\033[1;31m";
    private static String blue = "\033[34m";
    private static String yellow = "\033[33m";
    private static String green = "\033[32m";
    private static String purple = "\033[35m";
    private static String cyan = "\033[1;36m";
    private static String brightGreen = "\033[1;32m";
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        int enemiesKills = 0; // variable 
        Random random = new Random(); // variable
        Character player1 = null; // variable
        Character player2 = null; // variable
        int winner; // variable
        int p1Wins = 0;  // variable
        int p2Wins = 0; // variable
        int modeChoice = 0; // variable
        boolean playAgain = true; // variable

        System.out.println(red + "\t\t\t\t.  . ' +  .  . ' +   .  .  ' .   .    '   '+  .  . ' " + reset);
        System.out.println(red + "\t\t\t=======================================================================" + reset);
        System.out.println(red + "\n██████╗ ██╗      █████╗ ██████╗ ███████╗███████╗     ██████╗ ███████╗     █████╗  ██████╗ ██████╗ ██╗  ██╗   ██╗████████╗███████╗\r\n" + //
                        "██╔══██╗██║     ██╔══██╗██╔══██╗██╔════╝██╔════╝    ██╔═══██╗██╔════╝    ██╔══██╗██╔════╝██╔═══██╗██║  ╚██╗ ██╔╝╚══██╔══╝██╔════╝\r\n" + //
                        "██████╔╝██║     ███████║██║  ██║█████╗  ███████╗    ██║   ██║█████╗      ███████║██║     ██║   ██║██║   ╚████╔╝    ██║   █████╗  \r\n" + //
                        "██╔══██╗██║     ██╔══██║██║  ██║██╔══╝  ╚════██║    ██║   ██║██╔══╝      ██╔══██║██║     ██║   ██║██║    ╚██╔╝     ██║   ██╔══╝  \r\n" + //
                        "██████╔╝███████╗██║  ██║██████╔╝███████╗███████║    ╚██████╔╝██║         ██║  ██║╚██████╗╚██████╔╝███████╗██║      ██║   ███████╗\r\n" + //
                        "╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝     ╚═════╝ ╚═╝         ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝      ╚═╝   ╚══════╝\r\n" + //
                        "                                                                                                                                 " + reset);
        System.out.println(red + "\t\t\t=======================================================================" + reset);
        System.out.println(red + "\t\t\t\t.  . ' +  .  . ' +   .  .  ' .   .    '   '+  .  . ' " + reset);
        System.out.println();

        while(true){
            //ang game mode selection Func
            modeChoice = selectGameMode(scan); // method assig/n to int variable 
            if(modeChoice == 3){
                System.out.println(red + "\t\t\t\t\t\tThanks for playing Blades of Acolyte! Goodbye!" + reset);
                break;
            }
            do{
                //charachter selection function/method
                player1 = characterSelection(scan, 1, blue); //method assign to object

                if(modeChoice == 2){
                    player2 = characterSelection(scan, 2, cyan); // method assign to object
                    playAgain = true;

                    do{
                        winner = BattlePvP.startPvPBattle(player1, player2, scan); //method assign to object

                        switch(winner){
                            case 1:
                                p1Wins++;
                                break;
                            case 2:
                                p2Wins++;
                                break;
                        }

                        playAgain = askPlayAgain(scan); // method assign to boolean 
                        if(playAgain){
                            boolean changeCharacters = askChangeCharacters(scan); // method assign to boolean
                            if(changeCharacters){
                                player1 = characterSelection(scan, 1, blue); // method assign
                                player2 = characterSelection(scan, 2, cyan); // method assign 
                            }else{
                                player1.giveHealth(200);
                                player1.giveMana(200);
                                player2.giveHealth(200);
                                player2.giveMana(200);
                                System.out.println(brightGreen+"\n\t\t\t\t\t\tBoth players' health and mana have been restored!"+reset);
                            }
                        }
                    }while(playAgain);

                }else if(modeChoice == 1){
                    playAgain = true;

                    do{
                        Enemy enemy = EnemyFactory.generateRandomEnemy(random); // method assign to object
                        enemy.setName(green + enemy.getName() + reset); //method assign or function assign
                        enemiesKills += BattlePvE.startPvEBattle(player1, enemy, scan, random);  //method assign to variable
                        
   
                        playAgain = askPlayAgain(scan);
                        if(playAgain){
                            boolean changeCharacter = askChangeCharacters(scan); // method assign to boolean
                            if(changeCharacter){
                                player1 = characterSelection(scan, 1, blue); // method assign to object
                            }else{
                                player1.giveHealth(50); // object
                                player1.giveMana(50); // object
                                System.out.println(brightGreen+"\n\t\t\t\t\t\t" + player1.getName() + " healed 50 HP and restored 50 mana!"+reset);
                            }
                        }
                    }while(playAgain);
                }

                if(modeChoice == 2){
                    System.out.println(yellow+"\t\t\t\t\t\tScore: "+player1.getPlayerName()+" - " + p1Wins + " || "+player2.getPlayerName()+" - " + p2Wins + reset);
                }else if(modeChoice == 1){
                    System.out.println(red+"\t\t\t\t\t\tEnemies defeated: " + enemiesKills + reset);
                }

                while(true){
                    try{
                        System.out.print(brightGreen+"\n\t\t\t\t\t\tDo you want to return to the game mode selection? (Y/N): "+reset);
                        char returnChoice = scan.next().toUpperCase().charAt(0);

                        if(returnChoice == 'Y'){
                            playAgain = false; 
                            break;
                        }else if(returnChoice == 'N'){
                            System.out.println(red + "\t\t\t\t\t\tThanks for playing Blades of Acolyte! Goodbye!" + reset);
                            System.exit(0);
                        }else{
                            System.out.println("\t\t\t\t\t\tInvalid input! Please enter 'Y' or 'N'.");
                        }
                    }catch(Exception e){
                        System.out.println("\t\t\t\t\t\tInvalid input! Please try again.");
                        scan.nextLine(); 
                    }
                }

            }while(playAgain);
        }
    }

    private static int selectGameMode(Scanner scan){
        int modeChoice = 0;
        while(true){
            try{
                System.out.println(red + "\n\t\t\t\t\t\tChoose Game Mode:" + reset);
                System.out.println("\t\t\t\t\t\t1 - Player vs AI");
                System.out.println("\t\t\t\t\t\t2 - Player vs Player");
                System.out.println("\t\t\t\t\t\t3 - Exit Game");
                System.out.print("\t\t\t\t\t\tSelect mode: ");
                modeChoice = scan.nextInt();
                if(modeChoice >= 1 && modeChoice <= 3){
                    break;
                }else{
                    System.out.println("\t\t\t\t\t\tInvalid choice! Please select 1-3.");
                }
            }catch(Exception e){
                System.out.println("\t\t\t\t\t\tInvalid input! Please try again.");
                scan.nextLine(); 
            }
        }
        return modeChoice;
    }

    private static boolean askPlayAgain(Scanner scan){
        char choice;
        while(true){
            try{
                System.out.print(yellow+"\n\t\t\t\t\t\tDo you want to play again or have a rematch? (Y/N): "+reset);
                choice = scan.next().toUpperCase().charAt(0);

                if(choice == 'Y'){
                    return true;
                }else if(choice == 'N'){
                    return false;
                }else{
                    System.out.println("\t\t\t\t\t\tInvalid input! Please enter 'Y' or 'N'.");
                }
            }catch(Exception e){
                System.out.println("\t\t\t\t\t\tInvalid input! Please try again.");
                scan.nextLine();
            }
        }
    }

    private static boolean askChangeCharacters(Scanner scan){
        char choice;
        while(true){
            try{
                System.out.print(purple+"\n\t\t\t\t\t\tDo you want to change your character(s)? (Y/N): "+reset);
                choice = scan.next().toUpperCase().charAt(0);

                if(choice == 'Y'){
                    return true;
                }else if(choice == 'N'){
                    return false;
                }else{
                    System.out.println("\t\t\t\t\t\tInvalid input! Please enter 'Y' or 'N'.");
                }
            }catch(Exception e){
                System.out.println("\t\t\t\t\t\tInvalid input! Please try again.");
                scan.nextLine(); 
            }
        }
    }

    private static Character characterSelection(Scanner scan, int playerNumber, String color){
        Character player = null;
        
        int choice = 0;
        char letter;
        String playerName;
        scan.nextLine();

        System.out.print("\n\t\t\t\t\t\tPlayer " + playerNumber + ", enter your name: ");
        do{
            try{
                playerName = scan.nextLine().trim();
                if(playerName.isEmpty()){
                    System.out.print("\t\t\t\t\t\tName cannot be empty. Please enter a valid name: ");
                }else{
                    break; //if valid na
                }
            }catch(Exception e){
                System.out.println("\t\t\t\t\t\tError: Invalid input. Please try again.");
                scan.nextLine();
            }
        }while(true);

        do{
            try{
                System.out.println("\n\t\t\t\t\t\t"+ color + playerName + reset +" - Choose your character:");
                System.out.println("\t\t\t\t\t\t1 - Grayback");
                System.out.println("\t\t\t\t\t\t2 - Otomo");
                System.out.println("\t\t\t\t\t\t3 - Wildeye");
                System.out.println("\t\t\t\t\t\t4 - Shinja");
                System.out.println("\t\t\t\t\t\t5 - Budo");
                System.out.print("\t\t\t\t\t\tSelect: ");
                choice = scan.nextInt();
                scan.nextLine();

                switch (choice){
                    case 1: 
                        player = new Grayback();
                        break;
                    case 2 : 
                        player = new Otomo();
                        break;
                    case 3 : 
                        player = new Wildeye();
                        break;
                    case 4 : 
                        player = new Shinja();
                        break;
                    case 5 : 
                        player = new Budo();
                        break;
                    default : {
                        System.out.println("\t\t\t\t\t\tInvalid choice! Please input from 1-5 only.");
                        continue;
                    }
                }

                System.out.print("\t\t\t\t\t\tConfirm character choice (Y/N): ");
                letter = scan.next().toUpperCase().charAt(0);
                scan.nextLine();                
                 
                if(letter == 'N'){
                    player = null;
                }else if(letter != 'Y'){
                    System.out.println("\t\t\t\t\t\tInvalid input! Please enter 'Y' or 'N'.");
                    player = null; 
                }
            }catch(Exception e){
                System.out.println("\t\t\t\t\t\tInvalid input! Please enter a number between 1-5.");
                scan.nextLine();
            }
        }while(player == null);
  
        player.setPlayerName(color+ playerName + reset);
        player.setName(purple+ player.getName() + reset);
        System.out.println("\n\t\t\t\t\t\tYou have chosen "+player.getName()+" as your charater.");
        System.out.println("\t\t\t\t\t\tBackstory:\n");
        player.storyline();
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------");
        System.out.print("\n\t\t\t\t\t\tpress Enter to continue...");
        //scan.nextLine(); buffer pero di gamit
        return player;
    }
}
