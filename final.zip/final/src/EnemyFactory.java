import java.util.Random;

public class EnemyFactory{

    public static Enemy generateRandomEnemy(Random random){
        String[] enemyNames = {"\t\t\t\t\t\tZymeth", "Lady Yvaine", "Necromancer", "Kenji", "Issyl", "Gaihla"};
        String enemyName = enemyNames[random.nextInt(enemyNames.length)];

        int health = + random.nextInt(101)+100; 

        int attackDamage = 25 + random.nextInt(6);

        int mana = + random.nextInt(101)+100;
        
        return new Enemy(enemyName, health, attackDamage, mana);
    }
}
