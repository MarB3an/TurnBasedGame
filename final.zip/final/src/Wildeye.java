public class Wildeye extends Character{
    String reset = "\033[0m";
    String gray = "\033[1;30m";

    public Wildeye(){
        super("Wildeye", 125, 20, 175);
    }

    @Override
    public void storyline(){
        System.out.println(gray+"\t\t                  ,ood8888booo,\r\n" + //
                        "\t                      ,oda8a888a888888bo,\r\n" + //
                        "\t                   ,od88888888aa888aa88a8bo,\r\n" + //
                        "\t                 ,da8888aaaa88a888aaaa8a8a88b,\r\n" + //
                        "\t                ,oa888aaaa8aa8888aaa8aa8a8a88o,\r\n" + //
                        "\t               ,88888aaaaaa8aa8888a8aa8aa888a88,\r\n" + //
                        "\t               8888a88aaaaaa8a88aa8888888a888888\r\n" + //
                        "\t               888aaaa88aa8aaaa8888; ;8888a88888\r\n" + //
                        "\t               Y888a888a888a8888;'   ;888888a88Y\r\n" + //
                        "\t                Y8a8aa8a888a88'      ,8aaa8888Y\r\n" + //
                        "\t                 Y8a8aa8aa8888;     ;8a8aaa88Y\r\n" + //
                        "\t                  `Y88aa8888;'      ;8aaa88Y'\r\n" + //
                        "\t          ,,;;;;;;;;'''''''         ;8888Y'\r\n" + //
                        "\t       ,,;                         ,888P\r\n" + //
                        "\t      ,;  ,;,                      ;\"\"\r\n" + //
                        "\t     ;       ;          ,    ,    ,;\r\n" + //
                        "\t    ;  ;,    ;     ,;;;;;   ;,,,  ;\r\n" + //
                        "\t   ;  ; ;  ,' ;  ,;      ;  ;   ;  ;\r\n" + //
                        "\t   ; ;  ; ;  ;  '        ; ,'    ;  ;\r\n" + //
                        "\t   `;'  ; ;  '; ;,       ; ;      ; ',\r\n" + //
                        "\t        ;  ;,  ;,;       ;  ;,     ;;;\r\n" + //
                        "\t         ;,,;             ;,,;"+reset);
        System.out.println(gray+"\nDuring the Lotus occupation, Wildeye witnessed horrific and unimaginable acts committed by the Lotus Clan.\nHis cherished wife and only child were taken away to labor in the deep mines, never to return. Feeling\npowerless to protect them and unable to rescue his fellow Wolf brethren, he fled into the forests. There,\nhe learned to connect with nature and quietly plotted his revenge against the Lotus Clan.\n\nWildeye wields a boomerang, which he uses as a throwing weapon to defeat his enemies.\n"+reset);
    }
}
