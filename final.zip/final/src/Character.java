public abstract class Character{
    protected String name;
    protected int health;
    protected int attackDamage; 
    protected int mana;
    protected int maxHealth;
    protected int maxMana;
    protected String playerName;

    public Character(String name, int health, int attackDamage, int mana){
        this.name = name;
        this.health = health;
        this.attackDamage = attackDamage;
        this.mana = mana;
        maxHealth = health;
        maxMana = mana;
    }

    public void setPlayerName(String playerName){
        this.playerName = playerName;
    }

    public String getPlayerName(){
        return playerName;
    }

    public void setName(String name){
        this.name=name;
    }

    public String getName(){
        return name;
    }

    public int getHealth(){
        return health;
    }
    
    public int getMana(){
        return mana;
    }

    public abstract void storyline();

    public int attack(){
        return attackDamage;
    }

    public int specialAttack(){
        return attackDamage * 2;
    }

    public void defend(){
        attackDamage /= 2;
    }

    public void takeDamage(int damage){
        health -= damage;
        if(health<0){
            health = 0;
        }
    }
    public void giveHealth(int heal){
        health += heal;
        if(health>maxHealth){
            health = maxHealth;
        }
    }
    public void takeMana(int amount){
        this.mana -= amount;
        if(this.mana<0){
            this.mana = 0;
        }
    }
    public void giveMana(int amount){
        this.mana += amount;
        if(this.mana>maxMana){
            this.mana = maxMana;
        }
    }
}
