public class Enemy{
    private String name;
    private int health;
    private int attackDamage;
    private int mana;

    public Enemy(String name, int health, int attackDamage, int mana){
        this.name = name;
        this.health = health;
        this.attackDamage = attackDamage;
        this.mana = mana;
    }
    
    public void display(){
        System.out.print("\t\t\t\t\t\tEnemy's Stats:");
        System.out.print("\t\t\t\t\t\thealth:"+health);
        System.out.print("\t\t\t\t\t\tmana:"+mana);
    }
    
    public void takeDamage(int damage){
        this.health -= damage;
    }

    public void takeMana(int mana){
        this.mana -= mana;
    }

    public void giveMana(int mana){
        this.mana += mana;
    }

    public int getAttackDamage(){
        return attackDamage;
    }

    public int getHealth(){
        return health;
    }

    public int getMana(){
        return mana;
    }

    public void setName(String name){
        this.name=name;
    }

    public String getName(){
        return name;
    }
}
