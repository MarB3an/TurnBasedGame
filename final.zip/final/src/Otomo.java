public class Otomo extends Character{
    String reset = "\033[0m";
    String gray = "\033[1;30m";

    public Otomo(){
        super("Otomo", 200, 25, 150);
    }

    @Override
    public void storyline(){
        System.out.println(gray+"                           _____________                             \r\n" + //
                        "                     ,===:'.,            `-._                           \r\n" + //
                        "                            `:.`---.__         `-._                       \r\n" + //
                        "                               `:.     `--.         `.                     \r\n" + //
                        "                                 \\.        `.         `.                   \r\n" + //
                        "                         (,,(,    \\.         `.   ____,-`.,                \r\n" + //
                        "                      (,'     `/   \\.   ,--.___`.'                         \r\n" + //
                        "                  ,  ,'  ,--.  `,   \\.;'         `                         \r\n" + //
                        "                   `{D, {    \\  :    \\;                                    \r\n" + //
                        "                     V,,'    /  /    //                                    \r\n" + //
                        "                     j;;    /  ,' ,-//.    ,---.      ,                    \r\n" + //
                        "                     \\;'   /  ,' /  _  \\  /  _  \\   ,'/                    \r\n" + //
                        "                           \\   `'  / \\  `'  / \\  `.' /                     \r\n" + //
                        "                            `.___,'   `.__,'   `.__,'  "+reset);
        System.out.println(gray+"\nAfter the death of Taro, the last royal son of Tarrant's line, the Serpent Clan fell under the leadership\nof its chief ministers, with Lord Otomo being the most beloved by the people. Unlike Shinja, who ruled\nthrough fear, Otomo inspired loyalty and bravery through fairness, wisdom, and honorable behavior. He\nbelieved in the higher standards of Tarrant's rule, balancing his bureaucratic duties with his true passion\nfor battle.\n\nOtomo, a skilled general, excels in riding and fencing, wielding a massive nodachi, a Japanese long sword,\nto vanquish enemies. While some view him as weak, those who have faced him know of his strength and the\nmotivational presence he brings to his allies. Whispers suggest that he embodies the spirit of the old\nDragon Clan, reflecting a nobility and honor that contrasts sharply with the harsh methods of his\ncontemporaries.\n"+reset);
    }
}
