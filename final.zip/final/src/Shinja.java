public class Shinja extends Character{
    String reset = "\033[0m";
    String gray = "\033[1;30m";

    public Shinja(){
        super("Shinja", 135, 25, 175);
    }

    @Override
    public void storyline(){
        System.out.println(gray+"\t                            ,--.                       ,--.\r\n" + //
                        "\t                          _',|| )                     ( \\\\ |\r\n" + //
                        "\t            ,.,,.,-----\"\"' \"--v-.___                   `_\\\\.'--,..__\r\n" + //
                        "\t            |,\"---.--''/       /,.__\"\")`-:|._________-\"'     (--..__'/--.\r\n" + //
                        "\t                      /     ,.\"'    \"\"-'-\"|'  _.,-\"_.'-\"\\     \\     ` '\"\"\r\n" + //
                        "\t                   _ )____---------------(|--\"_|--'      '__   \\_\r\n" + //
                        "\t                _,' |  .''''\"\"---.        '\"\"'       ,---'''.   /\".\r\n" + //
                        "\t            _,-'  .\" \\/,,..---/_ /                   | -|.._____|  \\_\r\n" + //
                        "\t          ,-\\,.'''            \\ (                    |\"\")       \"-,  \\\r\n" + //
                        "\t      _ .\".--\"                ( :                    | (           '. \"\\_\r\n" + //
                        "\t    ,- ,.\"                    ; !                    ; |             \\,_ `.\r\n" + //
                        "\t___(_(.\"           -------....L_\">        _________.-/_J                '\\_')\r\n" +reset);
        System.out.println(gray+"\nOnce a slave, Shinja was taken in by the 'Veil of Shadows', a ruthless assassin organization. Trained in stealth and poison, he\nwields twin daggers: 'Natsukashii' for vengeance and 'Tetsu' for survival.As he rises through the ranks, Shinja discovers a\nconspiracy within the organization that mirrors the oppression he once endured. Betrayed by his mentor and faced with a moral\nchoice, Shinja must decide whether to remain a tool of the powerful or to dismantle the system that once enslaved him.\n\nIn a final showdown, he confronts his mentor, every strike embodying the conflict between his past and his future.\n"+reset);
    }
}
