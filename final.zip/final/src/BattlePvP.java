import java.util.Scanner;

public class BattlePvP{

    public static int startPvPBattle(Character player1, Character player2, Scanner scan){
        boolean again = false; // if mana is not enough or incorrect input
        int action1,action2;
        System.out.println("\n\t\t\t\t\t\t"+player1.getPlayerName()+" vs "+player2.getPlayerName()+" Battle Begins!");
                
        while(player1.getHealth() > 0 && player2.getHealth() > 0){
            
            do{
                System.out.println("\n\t\t\t\t\t\t"+player1.getName()+" HP: " + player1.getHealth() + "| Mana: "+player1.getMana()
                        + " "+player2.getName()+" HP: " + player2.getHealth()+ "| Mana: "+player2.getMana()+"\n");
                System.out.print("\t\t\t\t\t\t "+player1.getPlayerName()+" - Choose your action \n\t\t\t\t\t\t1 - Attack(+10 mana)\n\t\t\t\t\t\t2 - Defend(-25 mana)\n\t\t\t\t\t\t3 - Special Attack(-50 mana)");
                System.out.print("\n\t\t\t\t\t\tChoose: ");
                try{
                    action1 = scan.nextInt();
                    if (action1 < 1 || action1 > 3){
                        System.out.println("\t\t\t\t\t\tInvalid choice! You missed your chance!"); //hp will be deducted bisag wrong input ra
                        continue; 
                    }
                    again = ActionHandler.playerAction(player1, player2, action1);
                }catch(Exception e){
                    System.out.println("\t\t\t\t\t\tInvalid input! You missed your chance!"); // same here
                    scan.nextLine();
                    continue; 
                }
            }while(again);
            
            
            if(player2.getHealth() > 0){
                do{
                    System.out.println("\n\t\t\t\t\t\t"+player1.getName()+" HP: " + player1.getHealth() + "| Mana: "+player1.getMana()
                        + "\n\t\t\t\t\t\t"+player2.getName()+" HP: " + player2.getHealth()+ "| Mana: "+player2.getMana()+"\n\t\t\t\t\t\t");
                    System.out.print("\t\t\t\t\t\t "+player2.getPlayerName()+" - Choose your action \n\t\t\t\t\t\t1 - Attack(+10 mana)\n\t\t\t\t\t\t2 - Defend(-25 mana)\n\t\t\t\t\t\t3 - Special Attack(-50 mana)");
                    System.out.print("\n\t\t\t\t\t\tChoose: ");
                    try{
                        action2 = scan.nextInt();
                        if(action2 < 1 || action2 > 3){
                            System.out.println("\t\t\t\t\t\tInvalid choice! You missed your chance!"); // and here also
                            continue;
                        }
                        again = ActionHandler.playerAction(player2, player1, action2);
                    }catch(Exception e){
                        System.out.println("\t\t\t\t\t\tInvalid input! You missed your chance!"); //still the same
                        scan.nextLine();
                        continue; 
                    }
                }while(again);
            }
        }
        if(player1.getHealth() <= 0){
            System.out.println("\n\t\t\t\t\t\t"+player2.getPlayerName()+" Wins! "+player1.getPlayerName()+" has been defeated...");
            return 2;
        }
        else{
            System.out.println("\n\t\t\t\t\t\t"+player1.getPlayerName()+" Wins! "+player2.getPlayerName()+" has been defeated...");
            return 1;
        }

        
    }
}
