public class Budo extends Character{
    String reset = "\033[0m";
    String gray = "\033[1;30m";

    public Budo(){
        super("Budo", 100, 15, 100);
    }

    @Override
    public void storyline(){
        System.out.println(gray+"                         __    __    __    __\r\n" + //
                        "                        /  \\  /  \\  /  \\  /  \\\r\n" + //
                        "   ____________________/  __\\/  __\\/  __\\/  __\\_____________________________\r\n" + //
                        "   ___________________/  /__/  /__/  /__/  /________________________________\r\n" + //
                        "                      | / \\   / \\   / \\   / \\  \\____\r\n" + //
                        "                      |/   \\_/   \\_/   \\_/   \\    o \\\r\n" + //
                        "                                              \\_____/--<"+reset);
        System.out.println(gray+"\nIn the Serpent Clan, the governor Budo weighs four hundred pounds and is adept at administering an\nexceptionally efficient but tyrannical region. The peasants earn a living in a fear-driven\nenvironment where there is no respect for the leader as he is violent. Oppressive as he is, Budo\nhas punished, even killed liitle workers for minor offenses, making him so feared that even the heads\nof the Serpent Clan discarded their plans to promote him.\n\nWith his mere presence, productivity is also a guarantee as the threat of his rule keeps the peasants\nin check and focused. He is secretive about his past but at the age of 16 he seems to have left home.\nThe whip he uses on the battlefield is a huge barbed whip that zips around as freely as he wields it\nwhich is the same as his rule where mercy does not exist.\n"+reset);
    }
}
