public class Grayback extends Character{
    String reset = "\033[0m";
    String gray = "\033[1;30m";

    public Grayback(){
        super("Grayback", 175, 30, 150);
    }

    @Override
    public void storyline(){
        System.out.println("                    .'`'.'`'.\r\n" + //
                        "                 .''.`.  :  .`.''.\r\n" + //
                        "                 '.    '. .'    .'\r\n" + //
                        "                .```  .' '.  ```.\r\n" + //
                        "                 '..',`  :  `,'..'\r\n" + //
                        "                     `-'`'-`))\r\n" + //
                        "                            ((   \r\n" + //
                        "                             \\|");
        System.out.println(gray+"\nGrayback, once a slave under the Lotus Clan, led the Wolf Clan's rebellion for freedom. Driven by a fierce\nspirit, he overthrew their captors and became the clan’s leader. He aimed to restore the Wolf Clan's\nancient strength, reconnecting them with nature and embracing their primal roots.\n"+reset);
    }
}
