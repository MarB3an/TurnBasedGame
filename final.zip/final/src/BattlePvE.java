import java.util.Random;
import java.util.Scanner;

public class BattlePvE {

    public static int startPvEBattle(Character player, Enemy enemy, Scanner scan, Random random) {
        boolean again = false; // if mana is not enough
        int action = 0;
        String[] quotes = {"For the Clan!", "Taste death!", "The glory!", "No escape....", "Your will be done", "Die FOOL!", "I am your master!", "I seek!"};

        String[] attckQuote = {"Face me!", "You will pay for that!", "I will not falter!", "No escape....", "Let's do this!", "Your end is near!", "Feel the blade!", "I will show no mercy!"};

        String[] clan = {"Wolf", "Lotus", "Serpent", "Dragon"};

        System.out.println("\n\t\t\t\t\t\t" + enemy.getName() + " (" + clan[random.nextInt(clan.length)] + " Clan) says '" + attckQuote[random.nextInt(attckQuote.length)] + "'");

        while (player.getHealth() > 0 && enemy.getHealth() > 0) {
            again = false;

            do {
                System.out.println("\n\t\t\t\t\t\t" + player.getName() + " HP: " + player.getHealth() + " | Mana: " + player.getMana());
                System.out.println("\t\t\t\t\t\t" + enemy.getName() + " HP: " + enemy.getHealth() + " | Attack power: " + enemy.getAttackDamage());
                System.out.println("\n\t\t\t\t\t\t1 - Attack(+10 mana)\n\t\t\t\t\t\t2 - Defend(-25 mana)\n\t\t\t\t\t\t3 - Special Attack(-50 mana)\n");
                System.out.print("\t\t\t\t\t\t " + player.getPlayerName() + " - Choose your action: ");
                try {
                    action = scan.nextInt();
                    if (action < 1 || action > 3) {
                        System.out.println("\t\t\t\t\t\tInvalid choice! You missed your chance!"); //hp will be deducted bisag wrong input ra
                        scan.nextLine(); // consume the newline character
                        continue;
                    }
                    again = ActionHandler.playerAction(player, enemy, action, random);
                } catch (Exception e) {
                    System.out.println("\t\t\t\t\t\tInvalid input! You missed your chance!"); //same here
                    scan.nextLine(); // consume the invalid input
                    continue;
                }
            } while (again);

            if (enemy.getHealth() > 0) {
                int enemyDamage = random.nextInt(enemy.getAttackDamage());
                if (action == 2)
                    enemyDamage /= 2;
                player.takeDamage(enemyDamage);
                System.out.println("\t\t\t\t\t\t " + enemy.getName() + " says: \"" + quotes[random.nextInt(quotes.length)] + "\"");
                System.out.println("\t\t\t\t\t\t " + enemy.getName() + " dealt " + enemyDamage + " damage!");
                System.out.print("\n\t\t\t\t\t\tpress Enter to continue...");
                scan.nextLine(); // consume the newline character left after previous input
                scan.nextLine(); // wait for the user to press Enter
            }
        }

        if (player.getHealth() <= 0) {
            System.out.println("\n\t\t\t\t\t\tYou have been defeated...");
            return 0;
        } else {
            System.out.println("\n\t\t\t\t\t\tYou defeated " + enemy.getName() + "!");
            return 1;
        }
    }
}